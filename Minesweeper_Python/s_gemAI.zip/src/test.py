w = [[-5 for i in range(8)] for j in range(8)]
print(w[0][0])
w[0][1] = 2
print(w[0][1])